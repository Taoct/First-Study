Notice:
1:PythonPackageRequirement Package is the requirement install whl file or setup file
2:PythonPackageShowList is place the requirement list whl or set up file,and will show on UI
3.Download your need install file and put it in the two files,for the ui showing,have a few file in it 
4.Python_Package_Install_Tool.ini can setting your releated setup files,